// Copyright (c) 2018-2023  Robert J. Hijmans
//
// This file is part of the "spat" library.
//
// spat is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// (at your option) any later version.
//
// spat is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with spat. If not, see <http://www.gnu.org/licenses/>.

#include <vector>
#include <cstddef>
#include "cpl_error.h"

void vflip(std::vector<double> &v, const size_t &ncell, const size_t &nrows, const size_t &ncols, const size_t &nl, size_t data_offset = 0);

bool getGDALDataType(std::string datatype, GDALDataType &gdt);
std::string gdalinfo(std::string filename, std::vector<std::string> options, std::vector<std::string> openopts);
std::string gdalMDinfo(std::string filename, std::vector<std::string> options);
std::vector<std::vector<std::string>> sdinfo(std::string fname);
std::vector<std::string> get_metadata(std::string filename);
std::vector<std::string> get_metadata_sds(std::string filename);
std::vector<std::vector<std::string>> parse_metadata_sds(std::vector<std::string> meta);
void getGDALdriver(std::string &filename, std::string &driver);
bool getNAvalue(GDALDataType gdt, double & naval);
GDALDataset* openGDAL(std::string filename, unsigned OpenFlag, std::vector<std::string> allowed_drivers, std::vector<std::string> open_options);
void gdal_capture_messages_begin();
void gdal_capture_messages_end(bool emit);

// terra installs a CPL error handler at package load; sf (and others) may
// replace it afterward. Remember terra's handler and push it for the duration
// of terra GDAL opens so terra's filters (e.g. #2161 convert noise) still apply.
void gdal_set_terra_error_handler(CPLErrorHandler h);
void gdal_push_terra_error_handler();
void gdal_pop_terra_error_handler();

struct TerraGDALErrorHandlerScope {
	TerraGDALErrorHandlerScope() { gdal_push_terra_error_handler(); }
	~TerraGDALErrorHandlerScope() { gdal_pop_terra_error_handler(); }
	TerraGDALErrorHandlerScope(const TerraGDALErrorHandlerScope &) = delete;
	TerraGDALErrorHandlerScope &operator=(const TerraGDALErrorHandlerScope &) = delete;
};
char ** set_GDAL_options(std::string driver, double diskNeeded, bool writeRGB, bool parallel, unsigned threads, std::vector<std::string> gdal_options);
std::vector<std::string> ncdf_filternames(std::vector<std::string> const &s);
